# V4 当前本地开发状态

状态日期：2026-10-15（Asia/Shanghai）。本文件是当前进度与证据导航入口；机器工件、实际代码及测试结果优先于文字汇总。历史阶段文档和历史 eval 工件保持各自形成时的事实。

当前活跃版本为 **V4 本地版**，上传版在实际发布时再同步。STATE-02、DIAG-01～04 已完成：`cit-001` 的三次真实观察均有效，引用缺陷的当前归因受生成遗漏混杂，结论为 `NOT_ESTABLISHED_DUE_TO_CONFOUND`。本轮完成了诊断，没有形成引用产品修复或新的质量达标结论。

| 维度 | 当前身份 / 状态 | 证据入口 |
|---|---|---|
| 产品基线 | `V4_6_2_HASH_PORTABILITY_BASELINE` | [baseline lineage](../eval/v4_baseline_lineage.json)、[V4.6.2 baseline](../eval/v4_6_2_hash_portability_baseline.json) |
| canonical production source hash | `108fb167ee75a4b8657ad062185b51aef814e0586b9b0be60b7a4cc51141798c`（core / desktop / web），本轮未变 | 同上；工程与诊断工具身份另行绑定 |
| Full-144 指标来源 | `V4_6_1_EMBEDDING_IDENTITY_BASELINE`，登记于 2026-09-11；V4.6.2 与本轮均未重测 Full-144 | [V4.6.1 baseline](../eval/v4_6_1_embedding_identity_baseline.json) |
| 最近完成诊断 | 2026-10-15 WS-13 `cit-001` fresh attribution；三轮有效，Generation confound 已触发，引用缺陷未建立 | [本轮诊断报告](V4_WS13_FRESH_ATTRIBUTION_20261015.md)、[G4](../eval/v4_ws13_g4_observations_20261015.json)、[G5](../eval/v4_ws13_g5_attribution_20261015.json) |
| 历史诊断位置 | V4.8.2 达到当时 frozen-evidence attribution ceiling；本轮未改写该历史结论 | [V4.8.2 报告](V4_8_2_RESIDUAL_DIFFERENTIAL_ATTRIBUTION.md) |
| 最近路线评审 | Post-V4.8.2 Priority Review 的 WS-13 推荐支持度仍为历史 `WEAK`；本轮未重新排名 | [Priority Review](V4_POST_V4_8_2_NEXT_WORKSTREAM_PRIORITY_REVIEW.md) |
| 当前 readiness | `R3 / FRESH_ATTRIBUTION`；separate execution 仍受 WS-11 相关依赖限制 | [G6](../eval/v4_ws13_g6_readiness_20261015.json) |
| 已完成工程任务 | STATE-01、ENG-01～04 | [前轮执行报告](../../KB-V4_STATE01_ENG04_执行报告_2026-10-14.md)、[父工程身份](../eval/v4_engineering_recovery_20261014.json) |
| 本轮完成任务 | STATE-02、DIAG-01、DIAG-02、DIAG-03、DIAG-04 | [本轮执行报告](../../KB-V4_STATE02_DIAG04_执行报告_2026-10-15.md) |
| 已发布快照 | `v4.0.0-alpha.2`；Development Snapshot / Pre-release，`NOT V4 Final` | [发布说明](V4_RELEASE_SNAPSHOT.md)、[CHANGELOG](../CHANGELOG.md) |
| 上传版本地身份 | `main`，HEAD `1efc74f1c5aa4021766ed443f68ef8c5046116e4`；未同步、未提交、未推送本轮工作 | 本地保护核验；本轮未核验远端 GitHub 状态 / CI |
| Product Quality DoD | `NOT_YET_PASS`；旧 Full-144 的三项 FAIL 继续保留 | 下方最近产品质量指标 |

## 本轮完成范围

本轮用户明确要求执行以下五项工作。该授权与 2026-09-16 Priority Review 的历史“未授权”字段分开记录；独立代理技术审查也不表述为历史人工接受记录。

| 任务 | 状态 | 结果与证据 |
|---|---|---|
| STATE-02 | 已完成 | README / INDEX 指向当前状态；Master 仅前置当前导航块并保留历史正文；原文与当前身份分别验证 |
| DIAG-01 | 已完成 | 核验 G1 / A001 / FC1 链及 G2_EQ4；补齐只读 G3 分类器、当前 Master 绑定和批次驱动及测试；形成独立代理技术审查 |
| DIAG-02 | 已完成 | TPR2 绑定最终实现、17 个 source roles、当前 Master、生产 / 数据身份及精确遥测目标；实际负向检查在调用前阻断 |
| DIAG-03 | 已完成 | 固定 `cit-001` 的 ordinal 1、2、3 三轮真实观察全部有效；额外运行 0，重试 0，逐轮状态链通过 |
| DIAG-04 | 已完成 | 冻结分类规则输出 G5 / G6；引用缺陷未建立，触发生成混杂；明确补充调查与产品修复边界 |

任务完成以形成有效证据和明确证据限制为标准，不要求预设找到 citation root cause。后续产品修复、Full-144 验收、EXE 更新和发布同步继续按[后续工作目录](../../KB-V4_后续工作目录_2026-10-14.md)分别执行。

## 本轮真实观察与后续方向

三轮使用同一冻结问题“GSM 使用 GMSK 调制，请指出出处。”，均进入 `qa / DEFAULT_QA`，向生成阶段送达 5 个上下文且包含精确的 `GMSK` 支持文本。模型原始输出和应用最终输出均只有字面量 `[材料1]`，未包含预期事实 `GMSK`。

| ordinal | 观察有效性 | raw / final | fact_present | evaluator elapsed_ms | QA 遥测追加 |
|---|---|---|---:|---:|---:|
| 1 | 有效；等价性 YES | `[材料1]` / `[材料1]` | 0 / 1 | 54041 | 1 条 |
| 2 | 有效；等价性 YES | `[材料1]` / `[材料1]` | 0 / 1 | 4692 | 1 条 |
| 3 | 有效；等价性 YES | `[材料1]` / `[材料1]` | 0 / 1 | 4678 | 1 条 |

G5 为 `CITATION_STATUS=NOT_ESTABLISHED`、`CITATION_CONFIDENCE=NOT_ESTABLISHED_DUE_TO_CONFOUND`；Generation / Retrieval / Measurement confound 分别为 `YES / NO / NO`。`RUN_VARIABILITY=NO` 指分类结果一致，不代表耗时相同，也不据本轮计时差异推导性能原因。

本轮证明了该问题在当前固定路径中出现“支持已送达、答案事实未生成”的现象。它没有证明独立 citation defect，也没有证明某个全局 Generation 因果机制。G6 按 A001 桥接规则保留 inherited historical 记录，readiness 继续为 `R3 / FRESH_ATTRIBUTION`；不能因三轮已经执行而自动降为 R0 或转成 CURRENT_NEGATIVE。

`PROD-02` 的 citation 产品修复条件尚未成立。最小补充调查应先对照已保存的真实 messages、材料标签格式及 raw → final 处理链，研究事实内容为何缺失；不能仅凭 `[材料1]` 就把原因定为标签格式，也不能直接添加引用补全。`PROD-01` 缓存并发一致性是独立、已有内存复现的 P0 工作，可作为后续工程优先项，不能当作本次 citation 现象的已证明根因。

TPR2 仅覆盖本轮三个既定 ordinal，现已全部消费。G6 的下一步类别不构成新的模型调用、重跑本批次、counterfactual 或产品修复授权；后续真实实验需重新固定范围和有效输入。

## WS-13 设计、实现与执行证据

| 入口 | 身份与用途 |
|---|---|
| [G0 preflight](../eval/v4_ws13_citation_fresh_attribution_preflight.json) | 原始 preflight，原字节保持 |
| [G1 base](../eval/v4_ws13_citation_fresh_attribution_design.json)、[A001](../eval/v4_ws13_citation_fresh_attribution_design_amendment_001.json)、[FC1](../eval/v4_ws13_citation_fresh_attribution_design_amendment_001_boundary_correction.json) | 本轮沿用的冻结设计链；有效设计 digest 为 `646d354284fe6a419e144ead01ffd879c7cd426a05346d523c350be178b2ea94` |
| [G2 observer](../scripts/observe_v4_ws13_citation_fresh_attribution.py)、[G2 tests](../tests/test_v4_ws13_citation_fresh_attribution.py) | 当前观察器与 268 项测试；不将静态 / 合成结果替代 G4 科学证据 |
| [G3 classifier](../scripts/classify_v4_ws13_citation_fresh_attribution.py)、[分类器测试](../tests/test_ws13_classifier.py) | 只读消费实际观察，输出 per-run / G5 与桥接 G6；分类阶段没有新增模型 / 嵌入 / 检索调用 |
| [批次驱动](../scripts/run_ws13_observation_batch.py)、[驱动测试](../tests/test_ws13_observation_batch.py)、[当前绑定测试](../tests/test_ws13_current_binding.py) | 调用前验证、固定三轮预算、逐轮文件增量验证与失败停止 |
| [历史 TPR1](../eval/v4_ws13_canonical_telemetry_permission_rule.json) | 历史候选规则，过期 source bindings 保留；不作为本轮执行规则 |
| [本轮 TPR2](../eval/v4_ws13_canonical_telemetry_permission_rule_002.json) | 本轮已消费的三轮规则；raw `5c014483c111837ac461d8301153f93676f2213ae50c49c4436d58a8f3e340d3`；不是未来重跑许可 |
| [独立技术审查](../../KB-V4_Recovery/20261014-WS13-204032/independent-ws13-review-final.json) | 独立代理针对精确最终规则的技术审查；不声称历史人工接受 |
| [G4 真实观察](../eval/v4_ws13_g4_observations_20261015.json)、[外部原始记录](../../KB-V4_Recovery/20261014-WS13-204032/g4-observations-20261015/batch-result.json) | 三轮原始 envelope、执行身份、输入 / 输出与遥测变化链 |
| [G5 归因](../eval/v4_ws13_g5_attribution_20261015.json)、[G6 readiness](../eval/v4_ws13_g6_readiness_20261015.json) | 本轮机器结论；事实边界与最小下一步见[诊断报告](V4_WS13_FRESH_ATTRIBUTION_20261015.md) |
| [父工程登记](../eval/v4_engineering_recovery_20261014.json)、[本轮 source revision](../eval/v4_ws13_20261014_source_revision.json) | 当前实现与两层历史档案分别绑定；不是新产品基线 |

## 工程验收与科学边界

本轮全量工程验收：1662 项，0 failures、0 errors、26 skipped，耗时 850.570 秒。Ruff、Python 源码编译及 3 个前端 JavaScript 语法检查通过。

本轮调用前保护检查包括：live production hash guard 6 项通过；工程 revision 19 项与 PPR 原 manifest 回归 1 项共 20 项通过；真实规则 raw SHA 错误、ordinal 4、缺少授权三种负向调用均在任何模型 / 嵌入 / 检索前阻断。G2 初次完整运行 268 项发现 3 个测试适配失败，后按实际原因修复并由 root 与独立代理分别复测 3 / 3 通过；原失败日志保存。最终完整结果以上述全量记录为准。

STATE-01 / ENG-01～04 的历史验收于 2026-10-14 完成：完整 unittest 1532 项，1506 成功、26 跳过、0 failures、0 errors；Ruff、Python 编译、三个前端 JavaScript 语法检查、Phase E 108 例、Phase F.2 37 / 37 通过。该历史记录不是本轮新增代码后的全量测试统计。

证据：[前轮工程报告](../../KB-V4_STATE01_ENG04_执行报告_2026-10-14.md)、[本轮执行报告](../../KB-V4_STATE02_DIAG04_执行报告_2026-10-15.md)。工程测试与单例诊断均不能代替 Full-144 产品质量验收或真实服务全路径验收。

V4.7 的 Document Identity Loss 排除结论继续保留；其 `MATERIAL_INDEX_REPRESENTATION_BIAS` 属于当时阶段表述。V4.8 建立异质干预响应，未建立混合因果机制；V4.8.1 只否定其当时具体 operationalized 表征；V4.8.2 未产生满足 emission gate 的 top hypothesis。本轮 Generation confound 不把这些历史结论提升为某个全局 Generation 因果机制已经建立。

## 最近产品质量指标

机器事实源：[V4.6.1 baseline](../eval/v4_6_1_embedding_identity_baseline.json)。登记时间为 2026-09-11 23:17:22（artifact 原字段）；它不是本轮测量时间。目标按[质量接受合同](V3_QUALITY_ACCEPTANCE_CONTRACT.md)保持。

| 指标 | 最近登记值 | 最终门槛 | 结果 |
|---|---:|---:|---|
| case_exact_fact_match_rate | 0.7292（105 / 144） | ≥ 0.80 | FAIL |
| fact_recall | 0.8535（268 / 314） | ≥ 0.90 | FAIL |
| false_refusal_rate | 0.0000 | ≤ 0.03 | PASS |
| citation_coverage | 0.4657 | ≥ 0.80 | FAIL |
| high_confidence_unsupported_rate | 0.0132 | ≤ 0.05 | PASS |
| invalid_citation_count | 0 | = 0 | PASS |
| citation_scope_violation | 0 | = 0 | PASS |

## 源码运行与现有 EXE

当前源码默认配置为 `bge-m3 / 1024 + qwen2.5:7b + SQLite`；源码 managed 库为 `data/library/documents.sqlite3`，工程审查时有 6 文档、637 块。当前源码使用 `python -m desktop` 启动。

现有[双击入口](../启动本地版.bat)运行 `runtime/LocalDatabaseQA/LocalDatabaseQA.exe`。只读包检查记录显示 EXE 修改时间为 2026-09-10，SHA256 为 `a19df9431444b0f819e5c104454ae9fdc0a567f4222d7f8d803e2fe4cabc842e`。运行包仍为旧内容：默认导入嵌入配置 `nomic-embed-text`、缺少当前源码的 embedding identity 启动校验和 `is_location_intent`，内置解析器只有 Markdown / TXT，包内 legacy 库为 1 文档 / 617 块。

旧包查询会读取库中记录的嵌入模型，包内库本身记录 `bge-m3`，因此不将上述配置差异解释为“所有问答必然使用错误模型”。现有[打包 spec](../windows_desktop.spec)包含旧 `textbooks.sqlite3`；仅重打包不会自动带入六文档 managed 主库。运行包更新安排为 `REL-01`。包检查详情见[项目状态分析](../../KB-V4_Project_Status_2026-10-14.md)。

## 状态入口与历史记录

[README](../README.md)与[文档索引](INDEX.md)指向本文件。[Master](V4_MASTER_REQUIREMENTS_AND_ROADMAP.md)保留 2026-09-16 历史正文，上方追加可机械识别的当前导航块。冻结阶段报告、旧规则和历史 eval 工件不随本轮状态变更改写。

本轮恢复点为 `KB-V4_Recovery/20261014-WS13-204032`：355 文件按 SHA256 核验，7 项实际恢复验证通过。新增诊断代码由[本轮工程修订](../eval/v4_ws13_20261014_source_revision.json)绑定；父工程登记与历史档案保持独立。生产代码、主库和上传版未随本轮诊断变更；三轮观察只按契约追加了 QA 遥测，最终记录与核验见[本轮执行报告](../../KB-V4_STATE02_DIAG04_执行报告_2026-10-15.md)。
