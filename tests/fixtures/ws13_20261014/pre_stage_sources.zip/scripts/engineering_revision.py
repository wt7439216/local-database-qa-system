"""Separate immutable historical source bytes from the current engineering revision.

The source archive contains exact bytes saved before STATE-01 / ENG-01..04.
Historical assertions retain their original hashes. Functional tests still use
the live implementation, whose canonical LF identity is independently checked.
This registry neither advances a product baseline nor authorizes WS-13 runs.
"""

from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "eval" / "v4_engineering_recovery_20261014.json"
REVISION_ID = "V4_ENGINEERING_RECOVERY_20261014"


class RevisionIdentityError(ValueError):
    """A registered source or historical archive has changed unexpectedly."""


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_lf_bytes(data: bytes) -> bytes:
    return data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")


def load_registry() -> dict:
    record = json.loads(REGISTRY.read_text(encoding="utf-8"))
    if record.get("revision_id") != REVISION_ID:
        raise RevisionIdentityError("unexpected engineering revision ID")
    payload = {key: value for key, value in record.items() if key != "semantic_digest"}
    digest = _sha256(json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8"))
    if digest != record.get("semantic_digest"):
        raise RevisionIdentityError("engineering registry semantic digest mismatch")
    return record


def _relative_path(relative_path: str) -> str:
    path = Path(relative_path)
    if path.is_absolute() or path.drive or ".." in path.parts:
        raise RevisionIdentityError("source path must stay relative to the workspace")
    return path.as_posix()


def current_source_bytes(relative_path: str) -> bytes:
    relative_path = _relative_path(relative_path)
    record = load_registry()
    entry = record["sources"].get(relative_path)
    if entry is None:
        raise RevisionIdentityError("unregistered source: " + relative_path)
    data = (ROOT / relative_path).read_bytes()
    if _sha256(canonical_lf_bytes(data)) != entry["current_canonical_lf_sha256"]:
        raise RevisionIdentityError("current source drift: " + relative_path)
    return data


def historical_source_bytes(relative_path: str) -> bytes:
    relative_path = _relative_path(relative_path)
    record = load_registry()
    entry = record["sources"].get(relative_path)
    if entry is None:
        raise RevisionIdentityError("unregistered historical source: " + relative_path)
    if entry.get("before_raw_sha256") is None:
        raise RevisionIdentityError("no pre-engineering source exists: " + relative_path)
    # A historical assertion cannot hide an unregistered change to live code.
    current_source_bytes(relative_path)
    archive = record["historical_archive"]
    archive_data = (ROOT / _relative_path(archive["path"])).read_bytes()
    if _sha256(archive_data) != archive["raw_sha256"]:
        raise RevisionIdentityError("historical source archive identity mismatch")
    with zipfile.ZipFile(io.BytesIO(archive_data)) as saved:
        data = saved.read(relative_path)
    if _sha256(data) != entry["before_raw_sha256"]:
        raise RevisionIdentityError("historical source identity mismatch: " + relative_path)
    return data


def historical_source_text(relative_path: str) -> str:
    # Match Path.read_text's universal-newline behavior, while the bytes API
    # retains the exact archived identity for historical raw-hash assertions.
    return canonical_lf_bytes(historical_source_bytes(relative_path)).decode("utf-8")


def verify_current_files() -> dict[str, str]:
    record = load_registry()
    return {
        relative_path: _sha256(canonical_lf_bytes(current_source_bytes(relative_path)))
        for relative_path in record["sources"]
    }
