# docs — 文档导航索引

> 本文件是 `docs/` 的**逻辑导航**，不复制其它文档正文。
> 用于区分：当前权威文档 / 当前发布文档 / 当前诊断参考 / 历史阶段证据 / 机器可读证据。
>
> **本轮不移动任何文件**（避免破坏脚本/测试/文档间的相对引用与发布前 diff）。目录重排留作未来独立授权。

### Current cold-start pointers（冷启动先读）

```text
current governance baseline   = V4_6_2_HASH_PORTABILITY_BASELINE
product metrics source        = V4_6_1_EMBEDDING_IDENTITY_BASELINE
current release               = v4.0.0-alpha.2（NOT V4 Final）
latest completed diagnosis    = V4.7 Closure（Document Identity Loss = DISPROVEN；Product root cause family = GENERATION）
V4.6 attribution docs         = HISTORICAL references（其解释已被 V4.7 强挑战，不再是 current authority）
candidate next diagnosis      = V4.8 — Generation / Prompt-Evidence Framing Mechanism Isolation
V4.8 execution                = NOT AUTHORIZED（等待单独授权）
```

---

## 1. Current Canonical Docs（当前权威文档）

| 文档 | 用途 |
|---|---|
| [`V4_MASTER_REQUIREMENTS_AND_ROADMAP.md`](V4_MASTER_REQUIREMENTS_AND_ROADMAP.md) | **V4 权威总控**：Must/Should/Deferred、当前状态、baseline lineage、Gate、路线与 V4 Final 条件。 |
| [`ARCHITECTURE.md`](ARCHITECTURE.md) | 当前**真实架构**（查询流 / Router / Scope / Retrieval / Embedding Identity / 后端 / Citation / 评测 / 治理）；不含 roadmap。 |
| [`../README.md`](../README.md) | 项目对外第一入口：当前状态、模型依赖、快速启动、质量状态、文档导航。 |
| [`../本地使用说明.md`](../本地使用说明.md) | 本地运行 / 配置 / 排错 / 手机访问。 |

## 2. Current Release Docs（当前发布文档）

| 文档 | 用途 |
|---|---|
| [`V4_RELEASE_SNAPSHOT.md`](V4_RELEASE_SNAPSHOT.md) | 本次 Development Snapshot 发布说明（baseline / 模型 / 指标 / 已完成 / 未完成）。 |
| [`../CHANGELOG.md`](../CHANGELOG.md) | 版本变更记录（V4 alpha + 历史）。 |

## 3. Current Diagnostic Reference（当前诊断参考）

> ⚠️ 这些是 **phase / reference evidence**，记录特定阶段的机械证据，**不是当前 master 状态**。
> 当前权威状态一律以 `V4_MASTER_REQUIREMENTS_AND_ROADMAP.md` 为准。

| 文档 | 角色 |
|---|---|
| [`V4_7_DOCUMENT_IDENTITY_ROOT_CAUSE.md`](V4_7_DOCUMENT_IDENTITY_ROOT_CAUSE.md) | **最近完成的诊断阶段（V4.7 Closure，已冻结）**：Document Identity Loss = `DISPROVEN`；Product root cause family = `GENERATION`；Measurement semantic issue = `SUPPORTED`（独立轨道）。 |
| [`V4_7_CLOSURE_GOVERNANCE_ALIGNMENT.md`](V4_7_CLOSURE_GOVERNANCE_ALIGNMENT.md) | V4.7 governance alignment 审计报告（current docs 对齐证据；本轮）。 |
| [`V4_EMBEDDING_IDENTITY_ALIGNMENT.md`](V4_EMBEDDING_IDENTITY_ALIGNMENT.md) | V4.6.1 embedding identity 收编证据（current governance baseline `V4_6_2` 的 parent provenance）。 |

## 4. Historical Phase Evidence（历史阶段证据）

> 记录当时事实，**不因当前状态变化而改写**。仅在有客观错误时修正。

| 文档 | 角色 |
|---|---|
| [`V4_EVALUATION_INTEGRITY.md`](V4_EVALUATION_INTEGRITY.md) | V4.2 canonical evaluator / initial baseline 证据。 |
| [`V4_FAILURE_ATTRIBUTION.md`](V4_FAILURE_ATTRIBUTION.md) | V4.3 failure attribution 重建证据。 |
| [`V4_INITIAL_BASELINE.md`](V4_INITIAL_BASELINE.md) | V4 initial baseline 记录。 |
| [`V4_SCOPE_OOS_REMEDIATION.md`](V4_SCOPE_OOS_REMEDIATION.md) | V4.4 Scope/OOS false-refusal remediation 证据。 |
| [`V4_ROUTING_REMEDIATION.md`](V4_ROUTING_REMEDIATION.md) | V4.5 routing over-trigger remediation 证据。 |
| [`V4_POST_ROUTING_ATTRIBUTION.md`](V4_POST_ROUTING_ATTRIBUTION.md) | V4.6 post-routing residual 归因快照（**历史**：其 `DOCUMENT_IDENTITY_FAILURE` primary 解释已被 V4.7 强挑战；artifact 保持不可变，不再作为 current 优先级依据）。 |
| `V3_*`（见下） | V3 冻结阶段的文档集（历史继承资料）。 |

V3 历史文档（`V3_*`，均为历史阶段记录）：

```text
V3_MASTER_REQUIREMENTS_AND_STATUS.md     V3 需求/实现/待办总清单（历史）
V3_FINAL_BASELINE.md                     V3 冻结锚点
V3_QUALITY_ACCEPTANCE_CONTRACT.md        V3 质量接受合同（Target 档，仍为当前 Gate 依据）
V3_DOD_SCOPE_AMENDMENT.md                V3 DoD scope 修订（deferred 非阻断项来源）
V3_PHASE_E_ROUTER_DECISION.md            V3 Phase E Router 决策
V3_PHASE_F3_CITATION_DECISION.md         V3 Phase F.3 语义引用决策（DEFER_L2）
V3_PHASE_F4_RELEASE_GATE.md              V3 Phase F.4 release gate
V3_PHASE_F4.1_CLOSURE.md                 V3 Phase F.4.1 收口
V3_RUNTIME_LIBRARY_DECISION.md           V3 运行时库身份决策
V3_SCHEMA_IMPACT_NOTE_PHASE_D.md         V3 Phase D schema 影响说明
V3_PROGRESS.md                           V3 进度记录
V3_IMPROVEMENT_PLAN.md                   V3 改进方案（历史建议）
```

其它：

```text
deferred_meta_queries.json               冻结的 deferred-metadata 查询集（数据）
reference/本地知识库问答系统_v3_详细改进方案.docx   历史参考材料
```

## 5. Machine-readable Evidence（机器可读证据）

> 下列 artifact 是**机器事实源**，其位阶高于任何 prose 文档。

| Artifact | 角色 |
|---|---|
| [`../eval/v4_baseline_lineage.json`](../eval/v4_baseline_lineage.json) | baseline lineage 与 current pointer（唯一权威指针）。 |
| [`../eval/v4_6_2_hash_portability_baseline.json`](../eval/v4_6_2_hash_portability_baseline.json) | **current governance baseline**（hash portability formalization）+ canonical production hash。 |
| [`../eval/v4_6_1_embedding_identity_baseline.json`](../eval/v4_6_1_embedding_identity_baseline.json) | **product metrics source**（canonical Full-144 指标；`metrics_recomputed_in_v4_6_2 = false`）+ frozen targets。 |
| [`../eval/v4_7_document_identity_root_cause.json`](../eval/v4_7_document_identity_root_cause.json) | **V4.7 closure 机器事实源**：Document Identity diagnosis + Product/Measurement 分轴 taxonomy + closure gates。 |
| [`../eval/v4_6_post_routing_attribution.json`](../eval/v4_6_post_routing_attribution.json) | V4.6 归因与优先级排序（**历史快照**；其 document-identity 解释已被 V4.7 强挑战，不再是 current next-phase 依据）。 |

---

## 6. 未来目录重排建议（仅建议，未实施）

为避免破坏引用，本轮**未**建立以下物理目录；未来可在独立授权下考虑：

```text
docs/
├── INDEX.md
├── ARCHITECTURE.md
├── V4_MASTER_REQUIREMENTS_AND_ROADMAP.md
├── V4_RELEASE_SNAPSHOT.md
├── current-evidence/     （当前诊断/归因参考）
├── phase-history/        （V4 阶段证据）
└── historical/           （V3 历史文档）
```
