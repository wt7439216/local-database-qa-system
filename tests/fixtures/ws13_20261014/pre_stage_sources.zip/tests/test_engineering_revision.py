"""Identity regressions for historical evidence and current engineering sources."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

import engineering_revision as revision  # noqa: E402


class EngineeringRevisionTests(unittest.TestCase):
    def test_every_current_registered_source_has_its_own_identity(self):
        registered = revision.load_registry()["sources"]
        checked = revision.verify_current_files()
        self.assertEqual(set(checked), set(registered))
        self.assertGreaterEqual(len(checked), 13)

    def test_archived_bytes_retain_original_raw_hashes(self):
        registered = revision.load_registry()["sources"]
        archived = [path for path, entry in registered.items()
                    if entry.get("before_raw_sha256") is not None]
        self.assertEqual(len(archived), revision.load_registry()["historical_archive"]["entries"])
        self.assertGreaterEqual(len(archived), 13)
        for path in archived:
            with self.subTest(path=path):
                data = revision.historical_source_bytes(path)
                self.assertEqual(hashlib.sha256(data).hexdigest(),
                                 registered[path]["before_raw_sha256"])

    def test_current_content_drift_cannot_be_hidden_by_a_valid_archive(self):
        path = "docs/V4_MASTER_REQUIREMENTS_AND_ROADMAP.md"
        original_read = Path.read_bytes

        def changed_read(target):
            data = original_read(target)
            return data + b"unexpected-content" if target == ROOT / path else data

        with mock.patch.object(Path, "read_bytes", changed_read):
            with self.assertRaisesRegex(revision.RevisionIdentityError, "current source drift"):
                revision.historical_source_bytes(path)

    def test_line_ending_conversion_preserves_current_content_identity(self):
        path = "docs/V4_MASTER_REQUIREMENTS_AND_ROADMAP.md"
        original_read = Path.read_bytes

        def lf_read(target):
            data = original_read(target)
            return revision.canonical_lf_bytes(data) if target == ROOT / path else data

        with mock.patch.object(Path, "read_bytes", lf_read):
            revision.current_source_bytes(path)

    def test_modified_archive_is_rejected(self):
        archive = ROOT / revision.load_registry()["historical_archive"]["path"]
        original_read = Path.read_bytes

        def changed_read(target):
            data = original_read(target)
            return data + b"unexpected-content" if target == archive else data

        with mock.patch.object(Path, "read_bytes", changed_read):
            with self.assertRaisesRegex(revision.RevisionIdentityError, "archive identity mismatch"):
                revision.historical_source_bytes("README.md")

    def test_registry_payload_change_requires_a_matching_semantic_digest(self):
        record = revision.load_registry()
        record["production_source_hash"] = "0" * 64
        with mock.patch.object(Path, "read_text", return_value=json.dumps(record)):
            with self.assertRaisesRegex(revision.RevisionIdentityError, "semantic digest mismatch"):
                revision.load_registry()

    def test_unregistered_and_outside_workspace_sources_are_rejected(self):
        for path in ("../outside.py", "missing.py", "C:/outside.py"):
            with self.subTest(path=path):
                with self.assertRaises(revision.RevisionIdentityError):
                    revision.historical_source_bytes(path)
